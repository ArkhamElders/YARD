// Główny plik systemu Foundry VTT
Hooks.once('init', async function() {
  console.log('YARD System | Initializing');
  // Rejestracja klas aktora i przedmiotu
  CONFIG.Actor.documentClass = YARDActor;
  CONFIG.Item.documentClass = YARDItem;

  // Definicje typów aktorów
  CONFIG.YARD = CONFIG.YARD || {};
  CONFIG.YARD.actorTypes = ["bohater", "npc", "potwor"];

  // Rejestracja helperów Handlebars
  Handlebars.registerHelper('sum', function(a, b) {
    return (Number(a) || 0) + (Number(b) || 0);
  });
  Handlebars.registerHelper('divide', function(a, b) {
    if (!b) return 0;
    return Math.floor((Number(a) || 0) / Number(b));
  });
});

// Klasa bazowa aktora
class YARDActor extends Actor {
  // Możesz dodać wspólne metody dla wszystkich aktorów
}

// Klasa aktora: Bohater
class YARDHero extends YARDActor {
  /**
   * Zwraca poziom na podstawie PD (data.details.xp)
   */
  get level() {
    const xp = this.system.details?.xp || 0;
    if (xp < 200) return 1;
    if (xp < 400) return 2;
    if (xp < 800) return 3;
    if (xp < 1600) return 4;
    // Dodaj kolejne progi według potrzeby
    return 5 + Math.floor((xp - 1600) / 1000);
  }

  /**
   * Zwraca próg PD do następnego poziomu
   */
  get nextLevelXp() {
    const xp = this.system.details?.xp || 0;
    if (xp < 200) return 200;
    if (xp < 400) return 400;
    if (xp < 800) return 800;
    if (xp < 1600) return 1600;
    // Każdy kolejny poziom +1000 PD
    return 1600 + 1000 * (this.level - 4);
  }
}

// Klasa aktora: NPC
class YARDNPC extends YARDActor {
  // Specyficzne metody i właściwości dla NPC
}

// Klasa aktora: Potwór/Przeciwnik
class YARDMonster extends YARDActor {
  // Specyficzne metody i właściwości dla potwora/przeciwnika
}

// Klasa przedmiotu
class YARDItem extends Item {
  // Przykładowa klasa przedmiotu
}
