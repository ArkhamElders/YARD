# YARD System for Foundry VTT

To jest szkielet własnego systemu do Foundry VTT, gotowy do dalszego rozwoju.

## Struktura katalogów
- `system.json` – manifest systemu
- `module/yard-system.js` – główny plik JS systemu
- `templates/` – szablony kart aktora i przedmiotu
- `styles/yard-system.css` – style systemu
- `icons/` – miejsce na ikony/grafiki

## Instalacja
1. Skopiuj cały folder systemu do katalogu `Data/systems` w Foundry VTT.
2. Wskaż plik `system.json` jako manifest przy dodawaniu systemu w Foundry VTT.

## Rozwój
- Rozwijaj klasy aktora i przedmiotu w `module/yard-system.js`.
- Dodawaj własne szablony do katalogu `templates/`.
- Dodawaj style do `styles/yard-system.css`.

## Licencja
MIT
